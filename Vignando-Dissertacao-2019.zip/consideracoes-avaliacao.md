# Ricardo
- As estruturas e rela��es foram bem estruturadas na SmartyOntology. Os t�picos b�sicos de experimenta��o em engenharia de software est�o bem representados e associados a literatura b�sica de experimenta��o quantitativa.

- O primeiro coment�rio, seria a altera��o de "SmartOntology" para "SmartyOntology". � uma contribui��o para a abordagem Smarty certo?

- A instrumenta��o dessa avalia��o foi validada em um estudo piloto? Acredito que a Ontologia poderia conter um t�pico chamado "Grupo de Controle" para avaliar a qualidade do experimento em LPS. Na maioria das vezes � dif�cil entender quais aspectos de determinadas tecnologias podem ser avaliadas em conjunto com LPS. Talvez criar Grupos de Controle como Academia ou Ind�stria e incluir os participantes em um estudo piloto. Tal grupo de controle pode estar associado a "Pilot Project" j� representado na SmartyOntology. 

- Quanto aos termos, � necess�ria uma revis�o dos termos utilizados na Ontologia, por exemplo, "Keyworld" para "Keywords". 


- Melhorias da Ontologia
    - Na modelagem, a "SPL artifacts" est� sozinha, por que? Ser� que poderia estar associada ao "SPL domain"? 

    - Senti falta de "Results" que poderia estar associada de algum modelo com "Discussion". Acredito que isso poderia ser uma recomenda��o de melhoria para a SmartyOntology.

    - Pensando an�lise qualitativa dos dados, acho que nenhuma modelagem ou representa��o foi criada em "Analyze" na Ontologia? 

    - Hoje existe um grande interesse na comunidade cient�fica em an�lises qualitativas, uma sugest�o seria estender a SmartOntology para tal contexto de an�lise. Entretanto, eu entendo que a SmartyOntology foi proposta para experimentos quantitativos, mas isso poderia ser uma extens�o ou trabalho futuro bem interessante para a comunidade cient�fica de LPS ou at� mesmo para a �rea de Ontologia em geral.